# Carpeta de Agentes y Herramientas (`agentes/`)

Esta carpeta contiene una copia editable y organizada de las definiciones del equipo permanente de 5 agentes de ingeniería de software. Puedes modificar estos archivos directamente para agregarles más herramientas, integrar servidores MCP o dotarlos de nuevas capacidades especializadas.

---

## 📁 Estructura del Directorio

```text
agentes/
├── README.md                  # Esta guía de uso y referencia rápida
├── GUIA_HERRAMIENTAS.md        # Catálogo detallado de herramientas nativas y servidores MCP
├── AGENTS.md                  # Protocolo de trabajo del equipo de 5 agentes
├── orquestador-lider/
│   └── agent.md               # Definición y herramientas del Líder / Arquitecto
├── ingeniero-core/
│   └── agent.md               # Definición y herramientas de Backend, Core y DB
├── ingeniero-ui/
│   └── agent.md               # Definición y herramientas de Frontend, UI/UX y Diseño
├── qa-tester/
│   └── agent.md               # Definición y herramientas de Pruebas y Testing
└── auditor-logica/
    └── agent.md               # Definición y herramientas de Auditoría y Debugging
```

---

## 🛠️ ¿Cómo agregar nuevas herramientas a un agente?

Cada agente tiene un encabezado en formato **YAML frontmatter** al inicio de su archivo `agent.md`:

```yaml
---
name: ingeniero-core
description: Especialista en arquitectura de software, backend y bases de datos.
mainAgent: false
subagent: true
model: inherit
tools:
  - view_file
  - grep_search
  - find_by_name
  - list_dir
  - write_to_file
  - replace_file_content
  - run_command
  - manage_task
  - send_message
  - search_web
  - read_url_content
  # --- Agrega aquí tus nuevas herramientas ---
  # - read_browser_page
  # - generate_image
  # - ask_question
---
```

### Opciones y flags avanzadas que puedes activar:
- `enable_mcp_tools: true` — Habilita el acceso a herramientas de servidores MCP externos (Chrome DevTools, base de datos, APIs externas).
- `enable_subagent_tools: true` — Permite que este agente pueda definir o invocar sus propios subagentes subordinados (`invoke_subagent`, `define_subagent`).
- `enable_write_tools: true` — Concede permisos para crear/editar archivos y correr comandos en el sistema.

---

## 🔄 Sincronización con el entorno activo (`.agents/`)

Cuando termines de actualizar tus agentes en esta carpeta `agentes/`, avísame y copiaré automáticamente las definiciones a `.agents/agents/` para que Antigravity las active inmediatamente en tus sesiones de trabajo.
