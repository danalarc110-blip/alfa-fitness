# Catálogo de Herramientas para Agentes en Antigravity

Esta guía describe todas las herramientas nativas, integraciones MCP y habilidades (*skills*) que puedes asignar a tus agentes en sus archivos `agent.md`.

---

## 1. 🗂️ Herramientas Nativas de Antigravity

### A. Inspección y Lectura de Código
- `view_file`: Permite ver el contenido completo o fragmentos específicos de archivos de texto o binarios (imágenes, PDFs, audios).
- `grep_search`: Búsqueda ultra rápida por expresiones regulares o texto exacto en todo el proyecto usando ripgrep.
- `find_by_name`: Búsqueda de archivos y directorios por patrones glob o extensiones.
- `list_dir`: Lista el contenido de un directorio con detalles de tamaño y estructura.

### B. Edición y Creación de Archivos
- `write_to_file`: Crea nuevos archivos o sobrescribe archivos existentes de forma atómica.
- `replace_file_content`: Realiza modificaciones precisas en bloques de código dentro de un archivo existente.

### C. Ejecución y Control del Sistema
- `run_command`: Ejecuta comandos de shell/PowerShell en el sistema (ej. `php artisan`, `composer`, `npm`, `phpunit`, `git`).
- `manage_task`: Administra procesos en segundo plano (consultar estado, enviar stdin, cancelar procesos o ver logs).
- `schedule`: Programa recordatorios puntuales o tareas cron recurrentes para monitoreo continuo.

### D. Coordinación y Multiagente
- `invoke_subagent`: Invoca uno o varios subagentes especializados en segundo plano.
- `define_subagent`: Define sobre la marcha nuevos tipos de subagentes personalizados para la sesión.
- `manage_subagents`: Lista, inspecciona el estado en tiempo real o finaliza subagentes.
- `send_message`: Permite a un agente enviar mensajes directos e instrucciones a otros subagentes o al líder.

### E. Navegación, Web y Búsqueda
- `search_web`: Realiza búsquedas en internet para consultar documentación oficial, errores de paquetes o estándares actualizados.
- `read_url_content`: Lee el contenido estático de páginas web, manuales o APIs en formato Markdown.
- `read_browser_page`: Permite interactuar con navegadores reales mediante automatización web.

### F. Diseño, Multimedia e Interacción
- `generate_image`: Genera o edita mockups de interfaz, diagramas visuales y recursos gráficos usando modelos generativos.
- `ask_question`: Muestra un formulario interactivo con opciones múltiples para solicitar confirmación o aclarar requerimientos con el usuario.

---

## 2. 🔌 Integraciones con Servidores MCP (Model Context Protocol)

Si activas `enable_mcp_tools: true` en el frontmatter del agente, o configuras `mcp_config.json`, el agente puede usar:

### A. Chrome DevTools MCP
- Inspección del DOM en vivo.
- Auditoría de accesibilidad (a11y).
- Análisis de métricas Core Web Vitals (LCP, CLS, INP).
- Captura y análisis de perfiles de memoria (detección de memory leaks).
- Inspección de solicitudes de red y consola del navegador en tiempo real.

### B. Bases de Datos MCP
- Conexión directa a MySQL, PostgreSQL o SQLite para inspeccionar esquemas, ejecutar consultas de prueba y validar migraciones.

### C. GitHub / GitLab MCP
- Crear Pull Requests, consultar issues, revisar comentarios de code review y gestionar ramas directamente.

---

## 3. 🎯 Asignación Recomendada por Especialidad

| Especialista | Herramientas recomendadas para agregar |
| :--- | :--- |
| **`orquestador-lider`** | Todas las herramientas nativas + `ask_question` + `schedule` + `invoke_subagent` + `manage_subagents`. |
| **`ingeniero-core`** | `view_file`, `write_to_file`, `replace_file_content`, `grep_search`, `find_by_name`, `run_command`, `manage_task`, `search_web`, `read_url_content` + MCP de Base de Datos. |
| **`ingeniero-ui`** | Herramientas de edición + `generate_image` + `read_browser_page` + MCP Chrome DevTools para validar diseño responsive y CSS. |
| **`qa-tester`** | `view_file`, `write_to_file`, `replace_file_content`, `run_command`, `manage_task` + MCP Chrome DevTools para pruebas automatizadas de interfaz y navegación. |
| **`auditor-logica`** | `view_file`, `grep_search`, `find_by_name`, `list_dir`, `run_command`, `manage_task` + `search_web` (para investigar vulnerabilidades y bugs de librerías). |
