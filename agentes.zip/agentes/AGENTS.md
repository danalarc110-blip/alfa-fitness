# Protocolo y Equipo de Agentes de Desarrollo de Software

Este repositorio cuenta con un equipo permanente de 5 agentes especializados para el ciclo de vida completo de ingeniería de software bajo Google Antigravity.

---

## 1. Composición del Equipo

| Agente | Rol | Tipo | Archivo de Configuración |
| :--- | :--- | :--- | :--- |
| **`orquestador-lider`** | Tech Lead, Arquitecto e Integrador | Principal & Subagente | [.agents/agents/orquestador-lider/agent.md](file:///.agents/agents/orquestador-lider/agent.md) |
| **`ingeniero-core`** | Programador Core, Backend & APIs | Subagente Especialista | [.agents/agents/ingeniero-core/agent.md](file:///.agents/agents/ingeniero-core/agent.md) |
| **`ingeniero-ui`** | Frontend, UX/UI & Accesibilidad | Subagente Especialista | [.agents/agents/ingeniero-ui/agent.md](file:///.agents/agents/ingeniero-ui/agent.md) |
| **`qa-tester`** | QA, Testing, Edge Cases & Regresión | Subagente Especialista | [.agents/agents/qa-tester/agent.md](file:///.agents/agents/qa-tester/agent.md) |
| **`auditor-logica`** | Depuración, Concurrencia & Lógica | Subagente Especialista | [.agents/agents/auditor-logica/agent.md](file:///.agents/agents/auditor-logica/agent.md) |

---

## 2. Flujo Operativo Multiagente (9 Fases)

```mermaid
flowchart TD
    A["FASE A: Reconocimiento (Líder)"] --> B["FASE B: División de Tareas"]
    B --> C1["FASE C: ingeniero-core (Backend & Lógica)"]
    B --> C2["FASE C: ingeniero-ui (Frontend & Visual)"]
    B --> C3["FASE C: qa-tester (Diseño de Pruebas)"]
    B --> C4["FASE C: auditor-logica (Análisis Predictivo)"]
    C1 --> D["FASE D: Primera Integración (Líder)"]
    C2 --> D
    C3 --> D
    C4 --> D
    D --> E["FASE E: Pruebas de Sistema (QA Tester)"]
    E --> F["FASE F: Auditoría de Lógica y Estado (Auditor)"]
    F --> G{"¿Defectos Detectados?"}
    G -- Sí --> H["FASE G: Corrección Quirúrgica"]
    H --> I["FASE H: Pruebas de Regresión"]
    I --> F
    G -- No --> J["FASE I: Verificación Final y Reporte al Usuario"]
```

---

## 3. Prioridades de Calidad y Reglas de Seguridad

1. **Corrección > Estabilidad > Mantenibilidad > UX/Diseño > Velocidad**: El código debe ser matemáticamente y funcionalmente correcto antes de optimizarlo o acelerarlo.
2. **"Ya funciona" no es evidencia**: Todo informe requiere comando ejecutado, código de salida y resultado medible.
3. **Prohibición de Soluciones Falsas**:
   - Prohibido silenciar excepciones o usar bloques `catch` vacíos.
   - Prohibido modificar o relajar aserciones en pruebas legítimas.
   - Prohibido hardcodear retornos para fingir que el sistema funciona.
   - Prohibido reemplazar módulos enteros cuando un ajuste localizado soluciona el problema de raíz.
4. **Seguridad y Secretos**: Nunca commitear credenciales, tokens ni claves privadas en archivos de código fuente.
